package cn.enjoyedu.nettybasic.echo;

import io.netty.channel.ChannelInboundHandlerAdapter;

/**
 * 类说明：自己的业务处理
 */
public class EchoServerHandler extends ChannelInboundHandlerAdapter {

}
