package cn.enjoyedu.proxy;

/**
 *@author Mark老师   享学课堂 https://enjoy.ke.qq.com 
 *
 *类说明：选择服务接口
 */
public interface IGetServant {
    void choice(String desc);
}
